let fs = require('fs');

console.log('fs',fs);
